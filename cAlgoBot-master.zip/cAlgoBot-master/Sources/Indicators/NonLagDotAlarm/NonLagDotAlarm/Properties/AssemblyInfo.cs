﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NonLagDotAlarm")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("NonLagDotAlarm")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("35f19c43-c7cc-4f53-b8e0-61caaf9cd8e8")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]